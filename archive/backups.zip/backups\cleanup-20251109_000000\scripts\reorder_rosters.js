// scripts/reorder_rosters.js
// Rewrites data/real_rosters_2025_26.js so that English, Spanish, then Italian team blocks
// are moved to the bottom in that order. Non-matching teams are kept at the top in their
// original order.

const fs = require('fs');
const path = require('path');

global.window = {};
require('../teams.js');
require('../data/real_rosters_2025_26.js');

const rosters = window.REAL_ROSTERS || {};
const originalOrder = Object.keys(rosters);

const english = (divisionsData[0] && divisionsData[0].teams) ? divisionsData[0].teams.map(t=>t.name) : [];
const spanish = (divisionsData[1] && divisionsData[1].teams) ? divisionsData[1].teams.map(t=>t.name) : [];
const italian = (divisionsData[2] && divisionsData[2].teams) ? divisionsData[2].teams.map(t=>t.name) : [];

function nm(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,'').replace(/[^a-z0-9]/g,''); }

const engSet = new Set(english.map(nm));
const spaSet = new Set(spanish.map(nm));
const itaSet = new Set(italian.map(nm));

// partition
const others = [];
const engPresent = [];
const spaPresent = [];
const itaPresent = [];
const unmatched = [];

originalOrder.forEach(k=>{
  const keyn = nm(k);
  if (engSet.has(keyn)) engPresent.push(k);
  else if (spaSet.has(keyn)) spaPresent.push(k);
  else if (itaSet.has(keyn)) itaPresent.push(k);
  else others.push(k);
});

// Desired final order: others (in original order), then English (in order of 'english' list), then Spanish, then Italian, then any remaining rosters not matched

const finalOrder = [];
// keep others as-is
others.forEach(k=> finalOrder.push(k));

// helper to push teams in canonical order if present
function pushInOrder(listOfNames, presentArray){
  listOfNames.forEach(name=>{
    // find matching key in presentArray by normalized match
    const found = presentArray.find(k=> nm(k) === nm(name));
    if (found) finalOrder.push(found);
  });
}

pushInOrder(english, engPresent);
pushInOrder(spanish, spaPresent);
pushInOrder(italian, itaPresent);

// append any keys not yet included
originalOrder.forEach(k=>{ if (!finalOrder.includes(k)) finalOrder.push(k); });

// build file content
const outLines = [];
outLines.push("// real_rosters_2025_26.js -- reordered by scripts/reorder_rosters.js");
outLines.push("window.REAL_ROSTERS = window.REAL_ROSTERS || {};\n");

finalOrder.forEach(teamName=>{
  const players = rosters[teamName] || [];
  outLines.push(`window.REAL_ROSTERS['${teamName.replace(/'/g,"\\'")}'] = [`);
  players.forEach(p=>{
    const pname = (p.name||p.player||p.Nome||p.nome) || '';
    const pos = (p.position||p.pos||p.Position||'') || '';
    outLines.push('  { "name": ' + JSON.stringify(pname) + ', "position": ' + JSON.stringify(pos) + ' },');
  });
  outLines.push('];\n');
});

const outPath = path.join(__dirname, '..', 'data', 'real_rosters_2025_26.js');
fs.writeFileSync(outPath, outLines.join('\n'));
console.log('Wrote reordered rosters to', outPath);
console.log('Final team order count:', finalOrder.length);
