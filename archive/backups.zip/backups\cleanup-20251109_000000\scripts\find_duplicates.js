global.window = {};
require('../data/real_rosters_2025_26.js');
const r = global.window.REAL_ROSTERS;
const counts = {};
Object.keys(r).forEach(team => {
  r[team].forEach(p => {
    const n = p.name.trim();
    counts[n] = counts[n] || new Set();
    counts[n].add(team);
  });
});
const dups = Object.keys(counts).filter(n => counts[n].size > 1).sort((a,b)=>counts[b].size-counts[a].size);
if(dups.length === 0) console.log('No duplicates found');
else dups.forEach(n => console.log(n, '-> appears in', Array.from(counts[n]).join(', ')));