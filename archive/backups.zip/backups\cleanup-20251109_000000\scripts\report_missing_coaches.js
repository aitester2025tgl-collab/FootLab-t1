// scripts/report_missing_coaches.js
// Loads the game data and lists any teams that do not have an assigned coach.

global.window = {};
require('../data/unemployed_coaches_2025_26.js');
require('../data/coaches_2025_26.js');
require('../services/coaches.js');
require('../teams.js');
require('../clubs.js');

const clubs = window.generateAllClubs();
const missing = (window.ALL_CLUBS || []).filter(c => !c.coach).map(c => c.team.name);
if (missing.length === 0) {
  console.log('All teams have coaches assigned.');
} else {
  console.log('Teams missing coaches:');
  missing.forEach(t => console.log(' - ' + t));
}

console.log('\nUnemployed pool (first 20):', (window.UNEMPLOYED_COACHES||[]).slice(0,20));
console.log('Registered coaches:', window.COACH_SERVICE.listAll().length);
