// utils.js

function luminance(color) {
  // implementation of luminance calculation
  // ...
}

function getReadableTextColor(backgroundLuminance) {
  // implementation of getting readable text color
  // ...
}

export { luminance, getReadableTextColor };