// scripts/demo_hire_fire.js
// Demo: pick a club with a coach, simulate 10 straight losses to trigger firing,
// then hire a coach from the unemployed pool and show events.

global.window = {};
require('../data/unemployed_coaches_2025_26.js');
require('../data/coaches_2025_26.js');
require('../services/coaches.js');
require('../teams.js');
require('../clubs.js');

// attach simple console handlers for fired/hired events
window.onCoachFired = ({ coach, teamName, club }) => {
  console.log(`EVENT: Coach FIRED -> ${coach.name} from ${teamName}`);
};
window.onCoachHired = ({ coach, teamName, club }) => {
  console.log(`EVENT: Coach HIRED -> ${coach.name} to ${teamName}`);
};

// ensure clubs generated and services initialized
const clubs = window.generateAllClubs();
console.log('Generated clubs:', (window.ALL_CLUBS||[]).length);

// find a club that currently has a coach assigned
const clubWithCoach = (window.ALL_CLUBS || []).find(c => c.coach);
if (!clubWithCoach) {
  console.error('No club with an assigned coach found for the demo.');
  process.exit(1);
}

console.log('Demo target club:', clubWithCoach.team.name, 'current coach:', clubWithCoach.coach);

// simulate 10 losses to trigger the firing check
for (let i = 0; i < 10; i++) {
  const coach = window.COACH_SERVICE.recordMatchResult(clubWithCoach.team.name, 'loss');
  console.log(`Simulated loss #${i+1} for ${clubWithCoach.team.name}; coach stats now: wins=${coach ? coach.stats.wins : 'N/A'}, losses=${coach ? coach.stats.losses : 'N/A'}`);
}

// At this point coach should be fired and club.coach should be null
console.log('Post-simulation club coach:', clubWithCoach.coach);

// Attempt to hire from unemployed pool
const hired = window.COACH_SERVICE.hireFromUnemployedForClub(clubWithCoach);
if (hired) {
  console.log('Hired coach:', hired.name, '-> club coach now:', clubWithCoach.coach);
} else {
  console.log('No available coach to hire from unemployed pool.');
}

// show current unemployed pool snapshot
console.log('UNEMPLOYED_POOL (first 10):', (window.UNEMPLOYED_COACHES || []).slice(0,10));

// show coach service summary for the target coach name (if exists)
console.log('Registered coaches count:', window.COACH_SERVICE.listAll().length);

console.log('Demo complete.');
