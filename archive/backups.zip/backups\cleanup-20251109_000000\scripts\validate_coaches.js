// scripts/validate_coaches.js
global.window={};
require('../data/unemployed_coaches_2025_26.js');
require('../data/coaches_2025_26.js');
require('../services/coaches.js');
require('../teams.js');
require('../clubs.js');

const names=[
  'José Mourinho','Jürgen Klopp','Zinedine Zidane','Thomas Tuchel','Sérgio Conceição','Xavi Hernández','Massimiliano Allegri','Hansi Flick','Gareth Southgate','Mauricio Pochettino','Brendan Rodgers','Antonio Conte','Julen Lopetegui','Paulo Fonseca','Bruno Lage','Nuno Espírito Santo','Jesse Marsch','Frank Lampard','Fernando Santos','Luís Castro','Carlos Carvalhal','Paulo Bento','Vítor Bruno','Pedro Caixinha','Daniel Sousa','Luís Freire','José Peseiro','Petit','Tite','Jorge Sampaoli','Marcelo Gallardo'
];

const cs=window.COACH_SERVICE; const pool=window.UNEMPLOYED_COACHES||[];
console.log('Total registered coaches:', cs.listAll().length);
console.log('Unemployed pool length:', pool.length);
console.log('---');
names.forEach(n=>{
  const c = cs._internal.coachesByName[n];
  const inPool = pool.includes(n);
  const team = c && c.team ? c.team : null;
  const rep = c ? c.reputation : null;
  const status = team ? ('Employed at ' + team) : (inPool ? 'Unemployed (in pool)' : (c ? 'Registered (unemployed)' : 'Not registered'));
  console.log(n + ' -> ' + status + (rep !== null ? ('; rep='+rep) : ''));
});
