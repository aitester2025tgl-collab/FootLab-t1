// finance.js - stadium and finance helpers
(function(){
    function computeMatchAttendance(match) {
        if (!match || !match.homeClub) return { attendance: 0, capacity: 0 };
        const homeClub = match.homeClub;
        const awayClub = match.awayClub;
        const homePlayers = Array.isArray(match.homePlayers) ? match.homePlayers : (homeClub.team && Array.isArray(homeClub.team.players) ? homeClub.team.players : []);
        const awayPlayers = Array.isArray(match.awayPlayers) ? match.awayPlayers : (awayClub && awayClub.team && Array.isArray(awayClub.team.players) ? awayClub.team.players : []);

        const homeSkill = homePlayers.length ? homePlayers.reduce((s,p)=>s+(p.skill||0),0)/homePlayers.length : 50;
        const awaySkill = awayPlayers.length ? awayPlayers.reduce((s,p)=>s+(p.skill||0),0)/awayPlayers.length : 50;

        // Allow stadiums up to 100k capacity (user requested max)
        const rawCap = Number(homeClub.stadiumCapacity || homeClub.stadium || 10000);
        const effectiveCap = Math.max(500, Math.min(rawCap, 100000));

        const avgSkill = (homeSkill + awaySkill) / 2;
        // Base demand driven by average skill (quality), plus a popularity factor derived from members
        const skillFactor = (avgSkill / 100) * 0.6; // 0..0.6

        // popularity derived from members; normalize roughly between 0 and 1 where top clubs ~70000 members
        const homeMembers = Number(homeClub.members || homeClub.supporters || homeClub.fans || 1000);
        const popNorm = Math.max(0, Math.min(1, (homeMembers - 500) / 70000));
        const popFactor = popNorm * 0.3; // up to +0.3

        // small base demand to avoid zero attendance
        let demandPct = 0.05 + skillFactor + popFactor; // approx 0.05..0.95
        // slight bonus from recent performance (points) but capped
        const perfBonus = (homeClub && typeof homeClub.points === 'number') ? Math.min(0.15, (homeClub.points || 0) / 500) : 0;
        demandPct = Math.min(1, demandPct + perfBonus);

        // compute attendance and ensure sensible minimum (user wants the smallest clubs around ~500 on average)
        let attendance = Math.round(Math.max(500, Math.min(effectiveCap, Math.floor(effectiveCap * demandPct))));
        // edge-case: if effectiveCap is smaller than 500, clamp to effectiveCap
        if (effectiveCap < 500) attendance = Math.min(attendance, effectiveCap);

        return { attendance, capacity: effectiveCap };
    }

    function calcUpgradeCost(club, pct) {
        const currentCap = Number(club.stadiumCapacity || club.stadium || 10000);
        const seatsAdded = Math.ceil(currentCap * (pct/100));
        const costPerSeat = Math.round(20 + (currentCap / 1000) * 2);
        const total = seatsAdded * costPerSeat;
        return { seatsAdded, costPerSeat, total };
    }

    function applyUpgrade(club, pct) {
        const c = calcUpgradeCost(club, pct);
        const currentBudget = Number(club.budget || 0);
        if (c.total > currentBudget) throw new Error('Insufficient budget');
        const currentCap = Number(club.stadiumCapacity || club.stadium || 10000);
        const newCap = Math.min(100000, currentCap + c.seatsAdded);
        club.stadiumCapacity = newCap;
        club.budget = currentBudget - c.total;
        return { newCap, cost: c.total };
    }

    function estimateMatchRevenue(club, price) {
        // build fake match to compute attendance
        const match = { homeClub: club, awayClub: {} };
        const attendance = computeMatchAttendance(match).attendance;
        const ticketPrice = Number(price || club.ticketPrice || club.ticket || 20) || 20;
        return { attendance, estRevenue: Math.round(attendance * ticketPrice) };
    }

    function setTicketPrice(club, price) {
        club.ticketPrice = Math.max(1, Math.round(Number(price || club.ticketPrice || 20)));
        return club.ticketPrice;
    }

    window.Finance = window.Finance || {};
    window.Finance.computeMatchAttendance = computeMatchAttendance;
    window.Finance.calcUpgradeCost = calcUpgradeCost;
    window.Finance.applyUpgrade = applyUpgrade;
    window.Finance.estimateMatchRevenue = estimateMatchRevenue;
    window.Finance.setTicketPrice = setTicketPrice;
})();
