const fs = require('fs');
const path = require('path');

const rosterPath = path.join(__dirname, '..', 'data', 'real_rosters_2025_26.js');
const outPath = path.join(__dirname, '..', 'data', 'real_rosters_2025_26.clean.js');
// Load the file in a safe env
global.window = {};
require(rosterPath);
const rosters = global.window.REAL_ROSTERS || {};

function blockText(team, players) {
  const lines = [];
  lines.push(`window.REAL_ROSTERS['${team}'] = [`);
  lines.push('  // Goalkeepers');
  players.filter(p => p.position === 'GK').forEach(p => lines.push(`  { "name": "${p.name}", "position": "${p.position}" },`));
  lines.push('');
  lines.push('  // Defenders (CB / LB / RB)');
  players.filter(p => ['CB','LB','RB'].includes(p.position)).forEach(p => lines.push(`  { "name": "${p.name}", "position": "${p.position}" },`));
  lines.push('');
  lines.push('  // Midfield');
  players.filter(p => p.position === 'CM').forEach(p => lines.push(`  { "name": "${p.name}", "position": "${p.position}" },`));
  lines.push('');
  lines.push('  // Forwards (LW / RW / ST)');
  players.filter(p => ['LW','RW','ST'].includes(p.position)).forEach(p => lines.push(`  { "name": "${p.name}", "position": "${p.position}" },`));
  // remove trailing comma on last entry
  if (lines.length > 0) {
    const last = lines.length -1;
    lines[last] = lines[last].replace(/,\s*$/, '');
  }
  lines.push('];\n');
  return lines.join('\n');
}

let out = `// real_rosters_2025_26.js\n// Generated/cleaned by scripts/clean_rosters.js\n// This file maps team name -> array of players grouped into four blocks\n\nwindow.REAL_ROSTERS = window.REAL_ROSTERS || {};\n\n`;

Object.keys(rosters).sort().forEach(team => {
  out += blockText(team, rosters[team]);
});

fs.writeFileSync(outPath, out, 'utf8');
console.log('Wrote cleaned roster file to', outPath, 'with', Object.keys(rosters).length, 'teams');
